﻿using polo.Grpc.Protos;

namespace marco.API.GrpcServices
{
    public class AnswerGrpcService
    {
        private readonly AnswerProtoService.AnswerProtoServiceClient _answerProtoService;

        public AnswerGrpcService(AnswerProtoService.AnswerProtoServiceClient answerProtoService)
        {
            _answerProtoService = answerProtoService ?? throw new ArgumentNullException(nameof(answerProtoService));
        }

        public async Task<AnswerModel> GetAnswer( )
        {
            var answerRequest = new GetAnswerRequest { };

            return _answerProtoService.GetAnswer(answerRequest);
        }
        public async Task<AnswerModel> PostAnswer()
        {
            var answerRequest = new PostAnswerRequest { };

            return _answerProtoService.PostAnswer(answerRequest);
        }

        public async Task<AnswerModel> PutAnswer()
        {
            var answerRequest = new PutAnswerRequest { };

            return _answerProtoService.PutAnswer(answerRequest);
        }

        public async Task<AnswerModel> DeleteAnswer()
        {
            var answerRequest = new DeleteAnswerRequest { };

            return _answerProtoService.DeleteAnswer(answerRequest);
        }
    }
}
