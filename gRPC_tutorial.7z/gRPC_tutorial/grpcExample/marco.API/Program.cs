using marco.API.GrpcServices;
using polo.Grpc.Protos;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
ConfigurationManager configuration = builder.Configuration;

// Grpc Configuration
builder.Services.AddGrpcClient<AnswerProtoService.AnswerProtoServiceClient>(o => o.Address = new Uri(configuration.GetValue<string>("GrpcSettings:HostURL")));
builder.Services.AddScoped<AnswerGrpcService>();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
