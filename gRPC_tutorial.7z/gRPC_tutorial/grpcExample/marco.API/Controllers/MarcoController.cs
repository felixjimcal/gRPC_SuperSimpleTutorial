﻿using marco.API.GrpcServices;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace marco.API.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class MarcoController : ControllerBase
    {
        private readonly AnswerGrpcService _answerGrpcService;

        public MarcoController(AnswerGrpcService answerGrpcService)
        {
            _answerGrpcService = answerGrpcService ?? throw new ArgumentNullException(nameof(answerGrpcService));
        }

        [HttpGet("GetAnswer")]
        [ProducesResponseType(typeof(Answer), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<Answer>> GetAnswer()
        {
            return Ok(_answerGrpcService.GetAnswer());
        }

        [HttpPost("PostAnswer")]
        [ProducesResponseType(typeof(Answer), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<Answer>> PostAnswer()
        {
            return Ok(_answerGrpcService.PostAnswer());
        }

        [HttpPut("PutAnswer")]
        [ProducesResponseType(typeof(Answer), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<Answer>> PutAnswer()
        {
            return Ok(_answerGrpcService.PutAnswer());
        }

        [HttpDelete("DeleteAnswer")]
        [ProducesResponseType(typeof(Answer), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<Answer>> DeleteAnswer()
        {
            return Ok(_answerGrpcService.DeleteAnswer());
        }
    }
}
