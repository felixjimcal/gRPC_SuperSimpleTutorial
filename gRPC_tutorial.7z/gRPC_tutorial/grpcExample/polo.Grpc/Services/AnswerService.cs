﻿using Grpc.Core;
using polo.Grpc.Protos;

namespace polo.Grpc.Services
{
    public class AnswerService : AnswerProtoService.AnswerProtoServiceBase
    {

        public override async Task<AnswerModel> GetAnswer(GetAnswerRequest request, ServerCallContext context)
        {
            return new AnswerModel() { Text = "Get Polo" };
        }
        public override async Task<AnswerModel> PostAnswer(PostAnswerRequest request, ServerCallContext context)
        {
            return new AnswerModel() { Text = "Post Polo" };
        }

        public override async Task<AnswerModel> PutAnswer(PutAnswerRequest request, ServerCallContext context)
        {
            return new AnswerModel() { Text = "Put Polo" };
        }

        public override async Task<AnswerModel> DeleteAnswer(DeleteAnswerRequest request, ServerCallContext context)
        {
            return new AnswerModel() { Text = "Delete Polo" };
        }
    }
}
