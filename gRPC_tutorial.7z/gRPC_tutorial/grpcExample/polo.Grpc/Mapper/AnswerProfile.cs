﻿using AutoMapper;
using polo.Grpc.Models;
using polo.Grpc.Protos;

namespace polo.Grpc.Mapper
{
    public class AnswerProfile : Profile
    {
        public AnswerProfile() 
        {
            CreateMap<Answer, AnswerModel>().ReverseMap();
        }
    }
}
