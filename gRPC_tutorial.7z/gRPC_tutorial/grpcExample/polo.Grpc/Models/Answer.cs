﻿namespace polo.Grpc.Models
{
    public class Answer
    {
        public string Text { get; set; }
    }
}